"""AI Factory - Self-hosted Cloud Development Environment Platform."""

__version__ = "3.53.2"
